
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, AlertCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

type FeedbackType = 'success' | 'warning' | 'info';

interface FeedbackCardProps {
  title: string;
  message: string;
  type: FeedbackType;
  className?: string;
}

const FeedbackCard: React.FC<FeedbackCardProps> = ({
  title,
  message,
  type,
  className
}) => {
  const iconMap = {
    success: <CheckCircle className="h-5 w-5 text-green-500" />,
    warning: <AlertCircle className="h-5 w-5 text-amber-500" />,
    info: <Info className="h-5 w-5 text-blue-500" />
  };
  
  const colorMap = {
    success: 'border-l-4 border-l-green-500 bg-green-50',
    warning: 'border-l-4 border-l-amber-500 bg-amber-50',
    info: 'border-l-4 border-l-blue-500 bg-blue-50'
  };
  
  return (
    <Card className={cn(colorMap[type], 'shadow-sm', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center">
          {iconMap[type]}
          <span className="ml-2">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm">{message}</p>
      </CardContent>
    </Card>
  );
};

export default FeedbackCard;
