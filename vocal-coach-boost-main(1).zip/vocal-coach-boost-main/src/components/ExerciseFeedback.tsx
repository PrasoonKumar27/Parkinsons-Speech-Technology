
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, XCircle, AlertTriangle, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';

interface ExerciseFeedbackProps {
  exerciseType: string;
  performance: {
    volume: number;
    duration: number;
    consistency?: number;
  };
  targetVolume: number;
  targetDuration: number;
  onClose: () => void;
  onRetry: () => void;
  onContinue: () => void;
}

const ExerciseFeedback: React.FC<ExerciseFeedbackProps> = ({
  exerciseType,
  performance,
  targetVolume,
  targetDuration,
  onClose,
  onRetry,
  onContinue,
}) => {
  // Calculate overall score based on volume and duration (simple average)
  const volumeScore = performance.volume / targetVolume;
  const durationScore = performance.duration / targetDuration;
  const overallScore = ((volumeScore + durationScore) / 2) * 100;
  
  // Generate feedback messages
  const getVolumeFeedback = () => {
    if (performance.volume >= targetVolume * 1.2) {
      return "Your volume is excellent! Great projection.";
    } else if (performance.volume >= targetVolume) {
      return "Good volume. You've reached the target level.";
    } else if (performance.volume >= targetVolume * 0.8) {
      return "Your volume is slightly below target. Try to project your voice more.";
    } else {
      return "Your volume needs improvement. Focus on speaking louder.";
    }
  };
  
  const getDurationFeedback = () => {
    if (performance.duration >= targetDuration * 1.2) {
      return "Outstanding breath control! You exceeded the target duration.";
    } else if (performance.duration >= targetDuration) {
      return "Good breath control. You maintained speech for the target duration.";
    } else if (performance.duration >= targetDuration * 0.8) {
      return "You're close to the target duration. Keep practicing your breath control.";
    } else {
      return "Try to extend your speaking time with better breath support.";
    }
  };
  
  const getOverallFeedback = () => {
    if (overallScore >= 90) {
      return "Excellent work! You're performing very well on this exercise.";
    } else if (overallScore >= 75) {
      return "Good job! You're showing solid progress with this exercise.";
    } else if (overallScore >= 60) {
      return "You're on the right track. Regular practice will help you improve.";
    } else {
      return "This exercise needs more practice. Don't worry - improvement takes time.";
    }
  };
  
  // Exercise-specific tips
  const getExerciseTips = () => {
    switch (exerciseType) {
      case 'sustained-vowel':
        return "Try taking a deeper breath before starting and focus on maintaining consistent airflow.";
      case 'volume-variations':
        return "Practice controlling your volume in everyday conversations. Start sentences stronger.";
      case 'pitch-glides':
        return "Focus on the smooth transition between high and low pitches. Avoid abrupt changes.";
      default:
        return "Regular practice will help you improve your speech control and clarity.";
    }
  };
  
  return (
    <div className="space-y-6 p-4">
      <CardHeader className="p-0">
        <CardTitle className="text-xl">Exercise Feedback</CardTitle>
      </CardHeader>
      
      <div className="space-y-4">
        {/* Overall Score */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center mb-4">
              <div className="text-2xl font-bold">{Math.round(overallScore)}%</div>
              <div className="text-sm text-muted-foreground">Overall Score</div>
            </div>
            <Progress 
              value={overallScore} 
              className={`h-3 ${overallScore >= 70 ? 'bg-green-100' : overallScore >= 50 ? 'bg-yellow-100' : 'bg-red-100'}`} 
            />
          </CardContent>
        </Card>
        
        {/* Detailed Metrics */}
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Volume:</span>
                <span className={performance.volume >= targetVolume ? "text-green-600 font-medium" : "text-amber-600 font-medium"}>
                  {Math.round(volumeScore * 100)}%
                </span>
              </div>
              <Progress 
                value={volumeScore * 100} 
                className={`h-2 ${performance.volume >= targetVolume ? "bg-green-100" : ""}`} 
              />
              <p className="text-sm mt-1 text-muted-foreground">{getVolumeFeedback()}</p>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Duration:</span>
                <span className={performance.duration >= targetDuration ? "text-green-600 font-medium" : "text-amber-600 font-medium"}>
                  {Math.round(durationScore * 100)}%
                </span>
              </div>
              <Progress 
                value={durationScore * 100} 
                className={`h-2 ${performance.duration >= targetDuration ? "bg-green-100" : ""}`} 
              />
              <p className="text-sm mt-1 text-muted-foreground">{getDurationFeedback()}</p>
            </div>
            
            {performance.consistency !== undefined && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Consistency:</span>
                  <span className={performance.consistency > 0.7 ? "text-green-600 font-medium" : "text-amber-600 font-medium"}>
                    {Math.round(performance.consistency * 100)}%
                  </span>
                </div>
                <Progress 
                  value={performance.consistency * 100} 
                  className={`h-2 ${performance.consistency > 0.7 ? "bg-green-100" : ""}`} 
                />
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Overall Feedback */}
        <Alert className={overallScore >= 75 ? "border-green-500 bg-green-50" : overallScore >= 50 ? "border-yellow-500 bg-yellow-50" : "border-red-500 bg-red-50"}>
          <AlertTitle className="flex items-center">
            {overallScore >= 75 ? (
              <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            ) : overallScore >= 50 ? (
              <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
            ) : (
              <XCircle className="h-4 w-4 text-red-500 mr-2" />
            )}
            {getOverallFeedback()}
          </AlertTitle>
          <AlertDescription>
            <p className="mt-2">{getExerciseTips()}</p>
          </AlertDescription>
        </Alert>
        
        {/* Action Buttons */}
        <div className="flex gap-3 justify-between mt-6">
          <Button variant="outline" onClick={onRetry} className="flex-1">
            <ThumbsDown className="mr-2 h-4 w-4" />
            Try Again
          </Button>
          <Button onClick={onContinue} className="bg-coach-green hover:bg-coach-green-dark flex-1">
            <ThumbsUp className="mr-2 h-4 w-4" />
            Continue
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ExerciseFeedback;
