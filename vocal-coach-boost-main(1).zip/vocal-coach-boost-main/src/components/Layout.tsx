
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Mic, Activity, BarChart, Settings, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Home', icon: <Home className="h-5 w-5" /> },
    { path: '/exercises', label: 'Exercises', icon: <Mic className="h-5 w-5" /> },
    { path: '/progress', label: 'Progress', icon: <BarChart className="h-5 w-5" /> },
    { path: '/settings', label: 'Settings', icon: <Settings className="h-5 w-5" /> },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-white py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="h-6 w-6 text-coach-blue" />
            <h1 className="text-xl font-bold text-coach-blue">ParkinSpeak Coach</h1>
          </div>
        </div>
      </header>
      
      <main className="flex-1 container py-6">
        {children}
      </main>
      
      <nav className="sticky bottom-0 z-10 bg-white border-t">
        <div className="container">
          <div className="flex items-center justify-around">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex flex-col items-center py-3 px-4 text-sm",
                  location.pathname === item.path 
                    ? "text-coach-blue font-medium" 
                    : "text-gray-500 hover:text-coach-blue"
                )}
              >
                {item.icon}
                <span className="mt-1">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Layout;
