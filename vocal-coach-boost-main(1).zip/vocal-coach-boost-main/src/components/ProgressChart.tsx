
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DataPoint {
  date: string;
  volume?: number;
  pitch?: number;
  rate?: number;
  clarity?: number;
}

interface ProgressChartProps {
  data: DataPoint[];
  metrics: Array<'volume' | 'pitch' | 'rate' | 'clarity'>;
  title: string;
  className?: string;
}

const metricColors = {
  volume: '#4A90E2',
  pitch: '#4CAF50',
  rate: '#9C27B0',
  clarity: '#FF9800'
};

const metricLabels = {
  volume: 'Volume',
  pitch: 'Pitch Variation',
  rate: 'Speech Rate',
  clarity: 'Clarity'
};

const ProgressChart: React.FC<ProgressChartProps> = ({
  data,
  metrics,
  title,
  className
}) => {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => value.split(' ')[0]}
              />
              <YAxis />
              <Tooltip
                contentStyle={{ 
                  backgroundColor: 'white', 
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
                  border: 'none'
                }}
              />
              <Legend />
              {metrics.map((metric) => (
                <Line
                  key={metric}
                  type="monotone"
                  dataKey={metric}
                  stroke={metricColors[metric]}
                  name={metricLabels[metric]}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProgressChart;
