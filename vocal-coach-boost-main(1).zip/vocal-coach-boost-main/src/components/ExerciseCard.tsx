
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface ExerciseProps {
  id: string;
  title: string;
  description: string;
  category: 'volume' | 'pitch' | 'rate' | 'articulation';
  duration: number; // in minutes
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

const categoryColors = {
  volume: 'bg-coach-blue text-white',
  pitch: 'bg-coach-green text-white',
  rate: 'bg-purple-500 text-white',
  articulation: 'bg-orange-500 text-white',
};

const difficultyColors = {
  beginner: 'bg-green-100 text-green-800',
  intermediate: 'bg-yellow-100 text-yellow-800',
  advanced: 'bg-red-100 text-red-800',
};

const ExerciseCard: React.FC<ExerciseProps> = ({
  id,
  title,
  description,
  category,
  duration,
  difficulty,
}) => {
  return (
    <Card className="h-full transition-all hover:shadow-md">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-bold">{title}</CardTitle>
          <Badge className={categoryColors[category]}>
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Badge>
        </div>
        <CardDescription className="text-muted-foreground">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="outline" className={difficultyColors[difficulty]}>
            {difficulty}
          </Badge>
          <Badge variant="outline" className="bg-gray-100">
            {duration} min
          </Badge>
        </div>
      </CardContent>
      <CardFooter>
        <Link to={`/exercise/${id}`} className="w-full">
          <Button className="w-full bg-coach-blue hover:bg-coach-blue-dark">
            <Mic className="mr-2 h-4 w-4" />
            Start Exercise
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default ExerciseCard;
