
import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface AudioRecorderProps {
  onAudioDataAvailable?: (data: Float32Array) => void;
  showWaveform?: boolean;
  showVolumeIndicator?: boolean;
  targetVolume?: number;
  className?: string;
}

const AudioRecorder: React.FC<AudioRecorderProps> = ({
  onAudioDataAvailable,
  showWaveform = true,
  showVolumeIndicator = true,
  targetVolume = 0.5,
  className,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [volume, setVolume] = useState(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Setup canvas for waveform
  useEffect(() => {
    if (showWaveform && canvasRef.current) {
      const canvas = canvasRef.current;
      const canvasCtx = canvas.getContext('2d');
      
      if (canvasCtx) {
        canvasCtx.fillStyle = 'rgb(240, 246, 252)';
        canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [showWaveform]);
  
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      // Setup audio context and analyser
      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      
      const analyser = audioContext.createAnalyser();
      analyserRef.current = analyser;
      analyser.fftSize = 2048;
      
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      
      // Setup media recorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.start();
      setIsRecording(true);
      setIsPaused(false);
      
      // Start visualizing audio
      visualizeAudio();
      
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      
      setIsRecording(false);
      setIsPaused(false);
      
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      
      setVolume(0);
    }
  };
  
  const togglePause = () => {
    if (isRecording) {
      if (isPaused) {
        // Resume recording
        if (mediaRecorderRef.current) {
          mediaRecorderRef.current.resume();
          visualizeAudio();
        }
      } else {
        // Pause recording
        if (mediaRecorderRef.current) {
          mediaRecorderRef.current.pause();
          
          if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
            animationFrameRef.current = null;
          }
        }
      }
      
      setIsPaused(!isPaused);
    }
  };
  
  const visualizeAudio = () => {
    if (!analyserRef.current || !canvasRef.current) return;
    
    const analyser = analyserRef.current;
    const bufferLength = analyser.fftSize;
    const dataArray = new Float32Array(bufferLength);
    
    const canvas = canvasRef.current;
    const canvasCtx = canvas.getContext('2d');
    
    if (!canvasCtx) return;
    
    const WIDTH = canvas.width;
    const HEIGHT = canvas.height;
    
    const draw = () => {
      if (!analyserRef.current || !canvasCtx) return;
      
      animationFrameRef.current = requestAnimationFrame(draw);
      
      analyser.getFloatTimeDomainData(dataArray);
      
      if (onAudioDataAvailable) {
        onAudioDataAvailable(dataArray);
      }
      
      // Calculate volume (RMS)
      let sumSquares = 0;
      for (let i = 0; i < bufferLength; i++) {
        sumSquares += dataArray[i] * dataArray[i];
      }
      const rms = Math.sqrt(sumSquares / bufferLength);
      setVolume(rms);
      
      // Draw waveform if enabled
      if (showWaveform) {
        canvasCtx.fillStyle = 'rgb(250, 250, 252)';
        canvasCtx.fillRect(0, 0, WIDTH, HEIGHT);
        
        canvasCtx.lineWidth = 2;
        canvasCtx.strokeStyle = rms > targetVolume ? 'rgb(76, 175, 80)' : 'rgb(74, 144, 226)';
        
        canvasCtx.beginPath();
        
        const sliceWidth = WIDTH / bufferLength;
        let x = 0;
        
        for (let i = 0; i < bufferLength; i++) {
          const v = dataArray[i] * 3; // Amplify for better visualization
          const y = (v * HEIGHT / 2) + (HEIGHT / 2);
          
          if (i === 0) {
            canvasCtx.moveTo(x, y);
          } else {
            canvasCtx.lineTo(x, y);
          }
          
          x += sliceWidth;
        }
        
        canvasCtx.lineTo(WIDTH, HEIGHT / 2);
        canvasCtx.stroke();
      }
    };
    
    draw();
  };
  
  // Calculate volume indicator width
  const volumeWidth = `${Math.min(volume * 100 * 3, 100)}%`;
  const isTargetReached = volume > targetVolume;
  
  return (
    <div className={cn("flex flex-col space-y-4", className)}>
      {showWaveform && (
        <div className="waveform-container">
          <canvas 
            ref={canvasRef} 
            className="waveform"
            width={1000}
            height={100}
          />
        </div>
      )}
      
      {showVolumeIndicator && (
        <div className="flex flex-col space-y-1">
          <div className="flex justify-between text-sm">
            <span>Volume Level</span>
            {isTargetReached && <span className="text-coach-green">Target Reached!</span>}
          </div>
          <div className="volume-meter">
            <div 
              className="volume-level" 
              style={{ width: volumeWidth }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Quiet</span>
            <span>Target</span>
            <span>Loud</span>
          </div>
        </div>
      )}
      
      <div className="flex justify-center space-x-3">
        {!isRecording ? (
          <Button
            size="lg"
            onClick={startRecording}
            className="bg-coach-blue hover:bg-coach-blue-dark"
          >
            <Mic className="mr-2 h-5 w-5" />
            Start Recording
          </Button>
        ) : (
          <>
            <Button
              size="lg"
              variant="outline"
              onClick={togglePause}
              className="border-coach-blue text-coach-blue hover:bg-coach-blue/10"
            >
              {isPaused ? (
                <><Play className="mr-2 h-5 w-5" /> Resume</>
              ) : (
                <><Pause className="mr-2 h-5 w-5" /> Pause</>
              )}
            </Button>
            
            <Button
              size="lg"
              variant="destructive"
              onClick={stopRecording}
            >
              <Square className="mr-2 h-5 w-5" />
              Stop
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default AudioRecorder;
