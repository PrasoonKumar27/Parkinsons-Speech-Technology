
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mic, BarChart, Info, Clock, Badge } from 'lucide-react';
import Layout from '@/components/Layout';
import { useProgressStore } from '@/store/progressStore';

const Index = () => {
  const navigate = useNavigate();
  const { exercisesCompleted, minutesPracticed } = useProgressStore();
  
  const stats = [
    { 
      label: 'Exercises Completed', 
      value: exercisesCompleted.toString(), 
      icon: <Badge className="h-4 w-4 text-coach-blue" />,
      color: 'bg-blue-50'
    },
    { 
      label: 'Minutes Practiced', 
      value: minutesPracticed.toString(), 
      icon: <Clock className="h-4 w-4 text-coach-green" />,
      color: 'bg-green-50'
    },
  ];
  
  return (
    <Layout>
      <div className="space-y-6">
        <section className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-3">
            Welcome to ParkinSpeak Coach
          </h1>
          <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
            Your personal speech therapy assistant for improving speech clarity, 
            volume, and articulation.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              size="lg" 
              className="bg-coach-blue hover:bg-coach-blue-dark"
              onClick={() => navigate('/exercises')}
            >
              <Mic className="mr-2 h-5 w-5" />
              Start Exercises
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-coach-blue text-coach-blue hover:bg-coach-blue/10"
              onClick={() => navigate('/progress')}
            >
              <BarChart className="mr-2 h-5 w-5" />
              View Progress
            </Button>
          </div>
        </section>
        
        <div className="grid sm:grid-cols-2 gap-4">
          {stats.map((stat, index) => (
            <Card key={index} className="border-t-4 border-t-coach-blue">
              <CardContent className="p-6">
                <div className={`${stat.color} p-2 rounded-full w-10 h-10 flex items-center justify-center mb-3`}>
                  {stat.icon}
                </div>
                <h3 className="text-xl font-bold">{stat.value}</h3>
                <p className="text-muted-foreground text-sm">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <section className="mt-8">
          <Card className="bg-coach-gray-light">
            <CardContent className="p-6 flex items-start gap-4">
              <div className="bg-coach-blue rounded-full p-2 text-white mt-1 flex-shrink-0">
                <Info className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-medium mb-2">About ParkinSpeak Coach</h3>
                <p className="text-sm text-muted-foreground">
                  This application is designed to help people with Parkinson's disease improve their speech.
                  Regular practice with these exercises can help maintain voice volume, speech clarity, and
                  articulation. Please note that this is a supplementary tool and not a replacement for
                  professional speech therapy.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
};

export default Index;
