
import React from 'react';
import Layout from '@/components/Layout';
import ProgressChart from '@/components/ProgressChart';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Volume2, Mic, LineChart, ArrowUpRight, ArrowDownRight } from 'lucide-react';

// Mock data for progress charts
const weeklyData = [
  { date: 'Mon 10', volume: 60, pitch: 45, rate: 70, clarity: 55 },
  { date: 'Tue 11', volume: 65, pitch: 50, rate: 68, clarity: 58 },
  { date: 'Wed 12', volume: 70, pitch: 55, rate: 72, clarity: 60 },
  { date: 'Thu 13', volume: 68, pitch: 58, rate: 75, clarity: 63 },
  { date: 'Fri 14', volume: 75, pitch: 60, rate: 73, clarity: 65 },
  { date: 'Sat 15', volume: 80, pitch: 65, rate: 78, clarity: 70 },
  { date: 'Sun 16', volume: 78, pitch: 63, rate: 80, clarity: 68 },
];

const monthlyData = [
  { date: 'Week 1', volume: 60, pitch: 45, rate: 70, clarity: 55 },
  { date: 'Week 2', volume: 65, pitch: 50, rate: 72, clarity: 58 },
  { date: 'Week 3', volume: 70, pitch: 55, rate: 74, clarity: 60 },
  { date: 'Week 4', volume: 75, pitch: 60, rate: 76, clarity: 65 },
];

const ProgressPage = () => {
  const metrics = [
    { 
      name: 'Volume', 
      value: '78', 
      change: '+10%', 
      positive: true,
      icon: <Volume2 className="h-4 w-4 text-coach-blue" />,
      color: 'bg-blue-50'
    },
    { 
      name: 'Pitch Variation', 
      value: '63', 
      change: '+15%', 
      positive: true,
      icon: <LineChart className="h-4 w-4 text-coach-green" />,
      color: 'bg-green-50'
    },
    { 
      name: 'Speech Rate', 
      value: '80', 
      change: '+8%', 
      positive: true,
      icon: <Mic className="h-4 w-4 text-purple-500" />,
      color: 'bg-purple-50'
    },
    { 
      name: 'Clarity', 
      value: '68', 
      change: '+12%', 
      positive: true,
      icon: <Mic className="h-4 w-4 text-orange-500" />,
      color: 'bg-orange-50'
    },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Your Progress</h1>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{metric.name}</p>
                    <h3 className="text-2xl font-bold mt-1">{metric.value}</h3>
                  </div>
                  <div className={`${metric.color} p-2 rounded-full w-8 h-8 flex items-center justify-center`}>
                    {metric.icon}
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {metric.positive ? (
                    <ArrowUpRight className="h-4 w-4 text-green-500 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-red-500 mr-1" />
                  )}
                  <span className={metric.positive ? "text-green-500" : "text-red-500"}>
                    {metric.change}
                  </span>
                  <span className="ml-1 text-muted-foreground">since last week</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Tabs defaultValue="weekly" className="mt-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-medium">Progress Charts</h2>
            <TabsList>
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="weekly" className="mt-0 space-y-4">
            <ProgressChart 
              data={weeklyData} 
              metrics={['volume', 'pitch', 'rate', 'clarity']} 
              title="All Metrics (Weekly)"
            />
            
            <div className="grid md:grid-cols-2 gap-4">
              <ProgressChart 
                data={weeklyData} 
                metrics={['volume']} 
                title="Volume Progress"
              />
              <ProgressChart 
                data={weeklyData} 
                metrics={['pitch']} 
                title="Pitch Variation Progress"
              />
              <ProgressChart 
                data={weeklyData} 
                metrics={['rate']} 
                title="Speech Rate Progress"
              />
              <ProgressChart 
                data={weeklyData} 
                metrics={['clarity']} 
                title="Clarity Progress"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="monthly" className="mt-0 space-y-4">
            <ProgressChart 
              data={monthlyData} 
              metrics={['volume', 'pitch', 'rate', 'clarity']} 
              title="All Metrics (Monthly)"
            />
            
            <div className="grid md:grid-cols-2 gap-4">
              <ProgressChart 
                data={monthlyData} 
                metrics={['volume']} 
                title="Volume Progress"
              />
              <ProgressChart 
                data={monthlyData} 
                metrics={['pitch']} 
                title="Pitch Variation Progress"
              />
              <ProgressChart 
                data={monthlyData} 
                metrics={['rate']} 
                title="Speech Rate Progress"
              />
              <ProgressChart 
                data={monthlyData} 
                metrics={['clarity']} 
                title="Clarity Progress"
              />
            </div>
          </TabsContent>
        </Tabs>
        
        <Card>
          <CardHeader>
            <CardTitle>Exercise History</CardTitle>
            <CardDescription>Your recent exercise completion history</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground py-8">
              No exercise history data available yet. Complete exercises to see your history.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default ProgressPage;
