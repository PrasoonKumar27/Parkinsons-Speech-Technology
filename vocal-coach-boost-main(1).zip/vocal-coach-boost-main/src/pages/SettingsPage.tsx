
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

const SettingsPage = () => {
  const handleSave = () => {
    toast.success('Settings updated successfully');
  };
  
  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
            <CardDescription>
              Manage your personal information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" placeholder="Enter your first name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" placeholder="Enter your last name" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="Enter your email" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Exercise Settings</CardTitle>
            <CardDescription>
              Customize your exercise experience
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="exerciseDifficulty">Exercise Difficulty</Label>
                <p className="text-sm text-muted-foreground">
                  Adjust the difficulty level of exercises
                </p>
              </div>
              <Slider
                id="exerciseDifficulty"
                defaultValue={[50]}
                max={100}
                step={10}
                className="w-[180px]"
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="autoplay">Exercise Voice Prompts</Label>
                <p className="text-sm text-muted-foreground">
                  Enable voice instructions during exercises
                </p>
              </div>
              <Switch id="autoplay" defaultChecked={true} />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="targetVolume">Target Volume Level</Label>
                <p className="text-sm text-muted-foreground">
                  Set your target volume for volume exercises
                </p>
              </div>
              <Slider
                id="targetVolume"
                defaultValue={[60]}
                max={100}
                step={5}
                className="w-[180px]"
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="exerciseDuration">Default Exercise Duration</Label>
                <p className="text-sm text-muted-foreground">
                  Set default exercise duration in minutes
                </p>
              </div>
              <div className="w-[180px]">
                <Input 
                  id="exerciseDuration" 
                  type="number" 
                  min={1}
                  max={30}
                  defaultValue={5}
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>
              Manage your notification preferences
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="reminderNotifications">Exercise Reminders</Label>
                <p className="text-sm text-muted-foreground">
                  Receive reminders for daily exercises
                </p>
              </div>
              <Switch id="reminderNotifications" defaultChecked={true} />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="progressNotifications">Progress Updates</Label>
                <p className="text-sm text-muted-foreground">
                  Receive weekly progress report notifications
                </p>
              </div>
              <Switch id="progressNotifications" defaultChecked={true} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Privacy</CardTitle>
            <CardDescription>
              Manage your data and privacy settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="dataCollection">Speech Data Collection</Label>
                <p className="text-sm text-muted-foreground">
                  Allow collection of speech data to improve your experience
                </p>
              </div>
              <Switch id="dataCollection" defaultChecked={true} />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="shareProgress">Share Progress with Healthcare Provider</Label>
                <p className="text-sm text-muted-foreground">
                  Allow sharing progress data with your healthcare provider
                </p>
              </div>
              <Switch id="shareProgress" defaultChecked={false} />
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button onClick={handleSave} className="bg-coach-blue hover:bg-coach-blue-dark">
            Save Settings
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default SettingsPage;
