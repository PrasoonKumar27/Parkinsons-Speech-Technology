import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Volume2, Mic, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import AudioRecorder from '@/components/AudioRecorder';
import FeedbackCard from '@/components/FeedbackCard';
import ExerciseFeedback from '@/components/ExerciseFeedback';
import Layout from '@/components/Layout';
import { toast } from 'sonner';
import { useProgressStore } from '@/store/progressStore';

const exercisesInfo = {
  'sustained-vowel': {
    title: 'Sustained Vowel Exercise',
    description: 'This exercise helps improve breath support and vocal stability. Hold the "Ahh" sound as long as you can with a strong, steady voice.',
    instructions: [
      'Take a deep breath',
      'Say "Ahh" and hold it as long as you can',
      'Try to maintain a consistent volume above the target line',
      'Repeat 3 times'
    ],
    targetVolume: 0.5,
    targetDuration: 5, // in seconds
  },
  'volume-variations': {
    title: 'Volume Variations Exercise',
    description: 'Practice speaking at different volume levels to improve vocal flexibility and loudness control.',
    instructions: [
      'Start with your normal speaking volume',
      'Gradually increase your volume to your maximum',
      'Hold your maximum volume for 3 seconds',
      'Gradually decrease back to normal',
      'Repeat 3 times'
    ],
    targetVolume: 0.6,
    targetDuration: 10, // in seconds
  },
  'pitch-glides': {
    title: 'Pitch Glides Exercise',
    description: 'This exercise helps improve pitch range and vocal flexibility, which are important for expressive speech.',
    instructions: [
      'Take a deep breath',
      'Say "Ahh" starting at your lowest comfortable pitch',
      'Gradually glide up to your highest comfortable pitch',
      'Then glide back down to your lowest pitch',
      'Repeat 3 times'
    ],
    targetVolume: 0.4,
    targetDuration: 6, // in seconds
  },
  'default': {
    title: 'Speech Exercise',
    description: 'Follow the instructions below to complete this exercise.',
    instructions: [
      'Take a deep breath before starting',
      'Speak clearly and deliberately',
      'Try to maintain good volume throughout',
      'Complete all the steps as directed'
    ],
    targetVolume: 0.4,
    targetDuration: 5, // in seconds
  }
};

const ExerciseDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { increaseExercisesCompleted, addPracticeTime } = useProgressStore();
  
  const [currentRep, setCurrentRep] = useState(1);
  const [isCompleted, setIsCompleted] = useState(false);
  const [feedback, setFeedback] = useState<{ volume: number; duration: number; consistency?: number } | null>(null);
  const [showDetailedFeedback, setShowDetailedFeedback] = useState(false);
  
  const exerciseData = id && exercisesInfo[id as keyof typeof exercisesInfo] 
    ? exercisesInfo[id as keyof typeof exercisesInfo] 
    : exercisesInfo.default;
  
  const { title, description, instructions, targetVolume, targetDuration } = exerciseData;
  const totalReps = 3;
  
  const handleAudioDataAvailable = (data: Float32Array) => {
    // This would be where you'd analyze the audio in a real implementation
    // For now, we'll just simulate some basic analysis
    
    // Calculate volume (RMS)
    let sumSquares = 0;
    for (let i = 0; i < data.length; i++) {
      sumSquares += data[i] * data[i];
    }
    const rms = Math.sqrt(sumSquares / data.length);
    
    // In a real app, you would analyze pitch, rate, etc. here
    // console.log('Current volume:', rms);
  };
  
  const handleComplete = () => {
    // Simulate calculating results
    const volumeScore = Math.random() * 0.5 + 0.5; // Random score between 0.5 and 1.0
    const durationScore = Math.random() * 0.5 + 0.5; // Random score between 0.5 and 1.0
    const consistencyScore = Math.random() * 0.5 + 0.5; // Random consistency score
    
    setFeedback({ 
      volume: volumeScore, 
      duration: durationScore,
      consistency: consistencyScore 
    });
    
    setShowDetailedFeedback(true);
  };
  
  const handleContinue = () => {
    setShowDetailedFeedback(false);
    
    if (currentRep < totalReps) {
      setCurrentRep(current => current + 1);
      setFeedback(null);
    } else {
      setIsCompleted(true);
      toast.success('Exercise completed! Great job!');
    }
  };
  
  const handleRetry = () => {
    setShowDetailedFeedback(false);
    setFeedback(null);
  };
  
  const handleFinish = () => {
    // Update progress when exercise is completed
    increaseExercisesCompleted();
    
    // Add approximate practice time (can be more accurate in a real app)
    const approximateMinutes = Math.ceil(currentRep * targetDuration / 60);
    addPracticeTime(approximateMinutes);
    
    // Navigate back to exercises page
    navigate('/exercises');
  };
  
  return (
    <Layout>
      <div className="mb-6 flex items-center">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate('/exercises')}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">{title}</h1>
      </div>
      
      <div className="mb-6">
        <p className="text-muted-foreground">{description}</p>
      </div>
      
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="bg-coach-gray-light p-4 rounded-lg">
            <h3 className="font-medium mb-3">Instructions</h3>
            <ol className="list-decimal pl-5 space-y-2">
              {instructions.map((instruction, index) => (
                <li key={index} className="text-sm">{instruction}</li>
              ))}
            </ol>
          </div>
          
          <div className="bg-coach-gray-light p-4 rounded-lg">
            <h3 className="font-medium mb-3">Exercise Goals</h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Target Volume:</span>
                  <span className="font-medium">Medium-Loud</span>
                </div>
                <div className="flex items-center gap-1">
                  <Volume2 className="h-4 w-4 text-coach-blue" />
                  <Progress value={targetVolume * 100} className="h-2" />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Target Duration:</span>
                  <span className="font-medium">{targetDuration} seconds</span>
                </div>
                <div className="flex items-center gap-1">
                  <Mic className="h-4 w-4 text-coach-blue" />
                  <Progress value={80} className="h-2" />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2 space-y-4">
          {!isCompleted ? (
            <>
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-medium">Repetition {currentRep} of {totalReps}</h2>
                <span className="text-sm text-muted-foreground">Progress: {Math.round((currentRep - 1) / totalReps * 100)}%</span>
              </div>
              
              <Progress value={(currentRep - 1) / totalReps * 100} className="h-2 mb-6" />
              
              <div className="border rounded-lg p-4">
                {showDetailedFeedback && feedback ? (
                  <ExerciseFeedback
                    exerciseType={id as string}
                    performance={feedback}
                    targetVolume={targetVolume}
                    targetDuration={targetDuration}
                    onClose={() => setShowDetailedFeedback(false)}
                    onRetry={handleRetry}
                    onContinue={handleContinue}
                  />
                ) : feedback ? (
                  <div className="space-y-4">
                    <h3 className="font-medium text-center">Results</h3>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Volume:</span>
                          <span className={feedback.volume > targetVolume ? "text-green-600 font-medium" : "text-amber-600 font-medium"}>
                            {feedback.volume > targetVolume ? "Excellent!" : "Needs improvement"}
                          </span>
                        </div>
                        <Progress value={feedback.volume * 100} className={`h-2 ${feedback.volume > targetVolume ? "bg-green-100" : ""}`} />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Duration:</span>
                          <span className={feedback.duration > 0.7 ? "text-green-600 font-medium" : "text-amber-600 font-medium"}>
                            {feedback.duration > 0.7 ? "Great!" : "Try longer"}
                          </span>
                        </div>
                        <Progress value={feedback.duration * 100} className={`h-2 ${feedback.duration > 0.7 ? "bg-green-100" : ""}`} />
                      </div>
                    </div>
                    
                    <FeedbackCard
                      title="Feedback"
                      message={
                        feedback.volume > targetVolume && feedback.duration > 0.7
                          ? "Excellent work! You maintained good volume and duration."
                          : feedback.volume > targetVolume
                          ? "Good volume, but try to hold the sound longer next time."
                          : feedback.duration > 0.7
                          ? "Good duration, but try to speak louder next time."
                          : "Try to speak louder and hold the sound longer next time."
                      }
                      type={feedback.volume > targetVolume && feedback.duration > 0.7 ? "success" : "info"}
                    />
                    
                    <div className="flex justify-center gap-3">
                      <Button 
                        variant="outline"
                        onClick={handleRetry}
                      >
                        Try Again
                      </Button>
                      <Button
                        className="bg-coach-green hover:bg-coach-green-dark"
                        onClick={() => setShowDetailedFeedback(true)}
                      >
                        See Detailed Feedback
                      </Button>
                    </div>
                    
                    {currentRep < totalReps && (
                      <div className="text-center text-sm text-muted-foreground">
                        Complete the current repetition to continue.
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <AudioRecorder
                      onAudioDataAvailable={handleAudioDataAvailable}
                      showWaveform={true}
                      showVolumeIndicator={true}
                      targetVolume={targetVolume}
                    />
                    
                    <Separator className="my-4" />
                    
                    <div className="flex justify-center">
                      <Button 
                        onClick={handleComplete}
                        className="bg-coach-green hover:bg-coach-green-dark"
                      >
                        <Check className="mr-2 h-4 w-4" />
                        Complete Repetition
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </>
          ) : (
            <div className="border rounded-lg p-6 text-center space-y-6">
              <div className="mx-auto bg-coach-green/20 rounded-full w-16 h-16 flex items-center justify-center">
                <Check className="h-8 w-8 text-coach-green" />
              </div>
              
              <div>
                <h2 className="text-xl font-bold mb-2">Exercise Completed!</h2>
                <p className="text-muted-foreground">
                  Great job! You've completed all repetitions of this exercise.
                </p>
              </div>
              
              <div className="pt-4">
                <Button
                  size="lg"
                  onClick={handleFinish}
                  className="bg-coach-blue hover:bg-coach-blue-dark"
                >
                  Finish Exercise
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default ExerciseDetailPage;
