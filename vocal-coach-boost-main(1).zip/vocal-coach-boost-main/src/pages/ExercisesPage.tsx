
import React from 'react';
import Layout from '@/components/Layout';
import ExerciseCard, { ExerciseProps } from '@/components/ExerciseCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const exercisesData: ExerciseProps[] = [
  {
    id: 'sustained-vowel',
    title: 'Sustained Vowel',
    description: 'Hold the "Ahh" sound steadily for as long as possible',
    category: 'volume',
    duration: 5,
    difficulty: 'beginner',
  },
  {
    id: 'volume-variations',
    title: 'Volume Variations',
    description: 'Practice speaking at different volume levels following the guide',
    category: 'volume',
    duration: 7,
    difficulty: 'intermediate',
  },
  {
    id: 'pitch-glides',
    title: 'Pitch Glides',
    description: 'Change pitch from low to high and back while saying "Ahh"',
    category: 'pitch',
    duration: 5,
    difficulty: 'beginner',
  },
  {
    id: 'sentence-intonation',
    title: 'Sentence Intonation',
    description: 'Read sentences with varied inflection and emphasis',
    category: 'pitch',
    duration: 8,
    difficulty: 'intermediate',
  },
  {
    id: 'slow-speech',
    title: 'Slow Speech Practice',
    description: 'Practice reading text at a deliberate, measured pace',
    category: 'rate',
    duration: 6,
    difficulty: 'beginner',
  },
  {
    id: 'articulation-drill',
    title: 'Articulation Drill',
    description: 'Practice "pa-ta-ka" sounds for clear consonant production',
    category: 'articulation',
    duration: 5,
    difficulty: 'beginner',
  },
  {
    id: 'functional-phrases',
    title: 'Functional Phrases',
    description: 'Practice everyday phrases with clear articulation',
    category: 'articulation',
    duration: 10,
    difficulty: 'intermediate',
  },
  {
    id: 'reading-passage',
    title: 'Reading Passage',
    description: 'Read a paragraph with focus on clarity and volume',
    category: 'volume',
    duration: 10,
    difficulty: 'advanced',
  },
];

const ExercisesPage = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Speech Exercises</h1>
      
      <Tabs defaultValue="all">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="volume">Volume</TabsTrigger>
          <TabsTrigger value="pitch">Pitch</TabsTrigger>
          <TabsTrigger value="rate">Rate</TabsTrigger>
          <TabsTrigger value="articulation">Articulation</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {exercisesData.map((exercise) => (
              <ExerciseCard key={exercise.id} {...exercise} />
            ))}
          </div>
        </TabsContent>
        
        {['volume', 'pitch', 'rate', 'articulation'].map((category) => (
          <TabsContent key={category} value={category} className="mt-0">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {exercisesData
                .filter(exercise => exercise.category === category)
                .map((exercise) => (
                  <ExerciseCard key={exercise.id} {...exercise} />
                ))
              }
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </Layout>
  );
};

export default ExercisesPage;
