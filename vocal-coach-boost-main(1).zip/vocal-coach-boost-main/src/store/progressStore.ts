
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ProgressState {
  exercisesCompleted: number;
  minutesPracticed: number;
  increaseExercisesCompleted: () => void;
  addPracticeTime: (minutes: number) => void;
  resetProgress: () => void;
}

export const useProgressStore = create<ProgressState>()(
  persist(
    (set) => ({
      exercisesCompleted: 0,
      minutesPracticed: 0,
      increaseExercisesCompleted: () => 
        set((state) => ({ exercisesCompleted: state.exercisesCompleted + 1 })),
      addPracticeTime: (minutes) => 
        set((state) => ({ minutesPracticed: state.minutesPracticed + minutes })),
      resetProgress: () => 
        set({ exercisesCompleted: 0, minutesPracticed: 0 }),
    }),
    {
      name: 'parkinspeak-progress',
    }
  )
);
